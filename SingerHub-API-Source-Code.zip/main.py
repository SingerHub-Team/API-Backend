import firebase_admin
from dotenv import load_dotenv
from firebase_admin import credentials, auth, firestore
from fastapi import FastAPI, Request
from pydantic import BaseModel
import requests
import os

# pip install python-dotenv
# Load variabel environment dari file .env
load_dotenv()
API_KEY = os.getenv("API_KEY")
DIR_FIREBASE_CONFIG = os.getenv("DIR_FIREBASE_CONFIG")
app = FastAPI()
cred = credentials.Certificate(DIR_FIREBASE_CONFIG)
firebase_admin.initialize_app(cred)

db = firestore.client()

## API Autentikasi (Register dan Login)
@app.post("/login")
async def login_user(request: Request):
    try:
        data = await request.json()
        email = data.get("email")
        password = data.get("password")

        # Membuat payload permintaan
        payload = {
            "email": email,
            "password": password,
            "returnSecureToken": True
        }

        # Mengirim permintaan ke API REST Firebase Authentication
        response = requests.post(
            "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword",
            params={"key": API_KEY},
            json=payload
        )

        # Memeriksa status respons dan mengambil ID pengguna
        if response.status_code == 200:
            user_data = response.json()
            uid = user_data["localId"]
            id_token = user_data["idToken"]
            return {"message": "Login berhasil", "uid": uid, "id_token": id_token}
        else:
            error_message = response.json()["error"]["message"]
            return {"message": "Login gagal", "error": error_message}

    except Exception as e:
        return {"message": "Login gagal", "error": str(e)}

@app.post("/logout")
async def logout_user(request: Request):
    try:
        data = await request.json()
        uid = data.get("uid")

        # Mencabut sesi pengguna dan membatalkan token ID yang valid
        auth.revoke_refresh_tokens(uid)
        return {"message": "Logout berhasil"}
    except Exception as e:
        return {"message": "Logout gagal", "error": str(e)}

class RegisterUser(BaseModel):
    email: str
    password: str
    nama_lengkap: str

@app.post("/register-account")
async def register_account(register_data: RegisterUser):
    try:
        email = register_data.email
        password = register_data.password
        nama_lengkap = register_data.nama_lengkap

        user = auth.create_user(email=email, password=password)

        # Menyimpan nama lengkap ke Firestore
        user_data = {
            "Nama_Lengkap": nama_lengkap
        }
        db.collection("UserSingerHub").document(user.uid).set(user_data)
        
        return {"message": "Pengguna berhasil didaftarkan", "uid": user.uid}
    except Exception as e:
        return {"message": "Gagal mendaftarkan pengguna", "error": str(e)}

class UserData(BaseModel):
    id: str
    nama_lengkap: str
    umur: int
    jenis_kelamin: str
    daerah_asal: str
    pengalaman_bernyanyi: int
    genre_musik: str
    keterampilan_alat_musik: str
    alamat_tempat_tinggal: str
    latitude: float
    longitude: float
    
class UserDataWithoutID(BaseModel):
    nama_lengkap: str
    umur: int
    jenis_kelamin: str
    daerah_asal: str
    pengalaman_bernyanyi: int
    genre_musik: str
    keterampilan_alat_musik: str
    alamat_tempat_tinggal: str
    latitude: float
    longitude: float

@app.post("/register-data-without-auth")
async def register_data_without_auth(request: Request):
    try:
        data = await request.json()
        register_data = RegisterData(**data)

        user_data = {
            "Nama_Lengkap": register_data.nama_lengkap,
            "Umur": register_data.umur,
            "Jenis_Kelamin": register_data.jenis_kelamin,
            "Daerah_Asal": register_data.daerah_asal,
            "Pengalaman_Bernyanyi": register_data.pengalaman_bernyanyi,
            "Genre_Musik": register_data.genre_musik,
            "Keterampilan_Alat_Musik": register_data.keterampilan_alat_musik,
            "Alamat_Tempat_Tinggal": register_data.alamat_tempat_tinggal,
            "Latitude": register_data.latitude,
            "Longitude": register_data.longitude
        }
        db.collection("UserSingerHub").document(register_data.id).set(user_data)
        
        return {"message": "Data pengguna berhasil disimpan"}
    except Exception as e:
        return {"message": "Gagal menyimpan data pengguna", "error": str(e)}

@app.post("/register-data/{uid}")
async def register_data(uid: str, request: Request):
    try:
        data = await request.json()
        register_data = UserData(**data)

        user_data = {
            "ID": register_data.id,
            "Nama_Lengkap": register_data.nama_lengkap,
            "Umur": register_data.umur,
            "Jenis_Kelamin": register_data.jenis_kelamin,
            "Daerah_Asal": register_data.daerah_asal,
            "Pengalaman_Bernyanyi": register_data.pengalaman_bernyanyi,
            "Genre_Musik": register_data.genre_musik,
            "Keterampilan_Alat_Musik": register_data.keterampilan_alat_musik,
            "Alamat_Tempat_Tinggal": register_data.alamat_tempat_tinggal,
            "Latitude": register_data.latitude,
            "Longitude": register_data.longitude
        }
        db.collection("UserSingerHub").document(uid).set(user_data)
        
        return {"message": "Data pengguna berhasil disimpan"}
    except Exception as e:
        return {"message": "Gagal menyimpan data pengguna", "error": str(e)}

## Perbarui Profil
@app.put("/update-profile/{uid}")
async def update_profile(uid: str, user_data: UserData):
    try:
        data = user_data.dict()
        # Memperbarui profil pengguna di database Firestore
        updated_data = {
            "ID": data.get("id"),
            "Nama_Lengkap": data.get("nama_lengkap"),
            "Umur": data.get("umur"),
            "Jenis_Kelamin": data.get("jenis_kelamin"),
            "Daerah_Asal": data.get("daerah_asal"),
            "Pengalaman_Bernyanyi": data.get("pengalaman_bernyanyi"),
            "Genre_Musik": data.get("genre_musik"),
            "Keterampilan_Alat_Musik": data.get("keterampilan_alat_musik"),
            "Alamat_Tempat_Tinggal": data.get("alamat_tempat_tinggal"),
            "Latitude": data.get("latitude"),
            "Longitude": data.get("longitude")
        }
        db.collection("UserSingerHub").document(uid).update(updated_data)
        return {"message": "Profil berhasil diperbarui"}
    except Exception as e:
        return {"message": "Gagal memperbarui profil", "error": str(e)}

@app.put("/update-profile-by-id/{id}")
async def update_profile_by_id(id: str, user_data: UserDataWithoutID):
    try:
        data = user_data.dict()
        # Memperbarui profil pengguna di database Firestore
        updated_data = {
            "Nama_Lengkap": data.get("nama_lengkap"),
            "Umur": data.get("umur"),
            "Jenis_Kelamin": data.get("jenis_kelamin"),
            "Daerah_Asal": data.get("daerah_asal"),
            "Pengalaman_Bernyanyi": data.get("pengalaman_bernyanyi"),
            "Genre_Musik": data.get("genre_musik"),
            "Keterampilan_Alat_Musik": data.get("keterampilan_alat_musik"),
            "Alamat_Tempat_Tinggal": data.get("alamat_tempat_tinggal"),
            "Latitude": data.get("latitude"),
            "Longitude": data.get("longitude")
        }
        db.collection("UserSingerHub").document(id).update(updated_data)
        return {"message": "Profil berhasil diperbarui"}
    except Exception as e:
        return {"message": "Gagal memperbarui profil", "error": str(e)}

## API Get User Data
@app.get("/get-user-data")
async def get_user_data(uid: str = None, id: str = None):
    try:
        if uid:
            doc_ref = db.collection("UserSingerHub").document(uid)
            doc = doc_ref.get()
            if doc.exists:
                user_data = doc.to_dict()
                return {"message": "Data pengguna ditemukan", "user_data": user_data}
            else:
                return {"message": "Data pengguna tidak ditemukan"}
        elif id:
            users_ref = db.collection("UserSingerHub")
            query = users_ref.document(id)
            data = query.get().to_dict()
            if data is None:
                return {"message": "User data not found"}
            return {"message": "Data pengguna ditemukan", "user_data": data}
        else:
            return {"message": "Parameter UID atau ID harus diberikan"}
    except Exception as e:
        return {"message": "Gagal mendapatkan data pengguna", "error": str(e)}

if __name__ == "__main__":
    # jalankan: uvicorn main:app --host 0.0.0.0 --port 8000
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
